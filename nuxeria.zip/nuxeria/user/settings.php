<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: ../public/login.php"); // Redirect to login if not logged in
    exit();
}

// Database connection
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "Nuxeria";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user data for display
$email = $_SESSION['user']['email']; // Get email from session
$stmt = $conn->prepare("SELECT name, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($name, $hashed_password); // Get both name and hashed password
$stmt->fetch();
$stmt->close();

$conn->close();

// Handle logout
if (isset($_POST['logout'])) {
    session_destroy(); // Destroy the session
    header("Location: ../public/login.php"); // Redirect to login page
    exit();
}

// Handle password update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Verify current password
    if (password_verify($current_password, $hashed_password)) {
        // Check if new passwords match
        if ($new_password === $confirm_password) {
            // Hash the new password and update it in the database
            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
            $stmt->bind_param("ss", $new_hashed_password, $email);
            $stmt->execute();
            $stmt->close();
            $conn->close();
            echo "<script>alert('Password updated successfully.');</script>";
        } else {
            echo "<script>alert('New passwords do not match.');</script>";
        }
    } else {
        echo "<script>alert('Current password is incorrect.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings - Nuxeria</title>
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <style>
        .settings-box {
            border: 1px solid #ccc; /* Border color */
            border-radius: 15px; /* Rounded edges */
            padding: 20px; /* Inner padding */
            margin: 20px auto; /* Center the box with auto margins */
            background-color: #5A5A5A; /* Light background color */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Shadow effect */
            max-width: 400px; /* Set a maximum width */
            width: 90%; /* Allow the box to be responsive */
        }
        h2, h3 {
            text-align: center; /* Center headings */
        }
        input[type="password"], input[type="text"], input[type="email"] {
            width: 100%; /* Set width to 100% of the container */
            padding: 10px; /* Add some padding */
            border: 1px solid #ccc; /* Border style */
            border-radius: 5px; /* Rounded corners */
            box-sizing: border-box; /* Include padding and border in the element's total width and height */
            margin-bottom: 15px; /* Add spacing between inputs */
        }
        .update-button, .logout-button {
            padding: 10px 15px; /* Adjust padding for size */
            border: none; /* Remove default border */
            border-radius: 25px; /* Rounded edges */
            background-color: #8A9A5B; /* Background color */
            color: white; /* Text color */
            font-size: 14px; /* Font size */
            cursor: pointer; /* Cursor changes to pointer on hover */
            transition: background-color 0.3s; /* Smooth transition for hover effect */
            margin-top: 10px; /* Space above buttons */
        }
        .update-button:hover, .logout-button:hover {
            background-color: #006400; /* Darker shade on hover */
        }

        /* Profile User Styles */
        .user-profile {
            position: relative; /* Position for absolute dropdown */
            display: inline-block; /* Aligns profile with other content */
            margin-left: auto; /* Align to the right of the header */
        }

        .profile-picture {
            cursor: pointer; /* Cursor change on hover */
        }

        .profile-picture img {
            width: 50px; /* Set desired width */
            height: 50px; /* Set desired height */
            border-radius: 50%; /* Circular profile picture */
            object-fit: cover; /* Maintain aspect ratio and cover the area */
            transition: transform 0.2s; /* Add hover effect */
        }

        .dropdown-menu {
            display: none; /* Hide by default */
            position: absolute; /* Position it absolutely */
            top: 60px; /* Position below the profile picture */
            right: 0; /* Align to the right */
            background-color: #333; /* Dropdown background color */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Shadow effect */
            z-index: 1000; /* Ensure it appears above other elements */
            padding: 10px; /* Padding inside the dropdown */
            min-width: 150px; /* Minimum width of dropdown */
        }

        .user-profile:hover .dropdown-menu {
            display: block; /* Show on hover */
        }

        .dropdown-menu a {
            display: block; /* Block display for links */
            color: white; /* Text color */
            padding: 10px 15px; /* Padding for links */
            text-decoration: none; /* Remove underline */
        }

        .dropdown-menu a:hover {
            background-color: #00FF88; /* Change background on hover */
        }
        .balance {
            color: #00FF88; /* Currency balance color */
            font-weight: bold; /* Bold font for emphasis */
            margin-bottom: 10px; /* Space below the balance */
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../assets/images/nuxeria-logo.png" alt="Nuxeria Logo">
        </div>
        <nav>
            <ul>
                <li><a href="dashboard2.html" class="nav-link">Dashboard</a></li>
                <li><a href="courses.html" class="nav-link">Courses</a></li>
            </ul>
        </nav>
        <div class="user-profile">
            <div class="profile-picture">
                <img src="../assets/images/default-profile.png" alt="Profile Picture" id="profileImg">
            </div>
            <div class="dropdown-menu">
                <div class="balance">Balance: $100.00</div> <!-- Currency Balance -->
                <a href="profile.php">View Profile</a>
                <a href="settings.php">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </header>

    <main class="settings">
        <div class="settings-box">
            <h2>Account Settings</h2>
            <div>
                <p><strong>Name:</strong> <?= htmlspecialchars($name) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($email) ?></p>
            </div>
            <br>
            <h3>Change Password</h3>
            <br>
            <form action="" method="POST">
                <div>
                    <label for="current_password">Current Password</label>
                    <input type="password" id="current_password" name="current_password" required>
                </div>
                <div>
                    <label for="new_password">New Password</label>
                    <input type="password" id="new_password" name="new_password" required>
                </div>
                <div>
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>
                <button type="submit" name="update_password" class="update-button">Update Password</button>
            </form>
            <form action="" method="POST">
                <button type="submit" name="logout" class="logout-button">Logout</button>
            </form>
        </div>
    </main>

    <script>
        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.profile-picture img')) {
                var dropdowns = document.getElementsByClassName("dropdown-menu");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.style.display === "block") {
                        openDropdown.style.display = "none";
                    }
                }
            }
        }
    </script>
</body>
</html>
