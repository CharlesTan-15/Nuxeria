<?php

session_start();
// Check if the user is logged in
if (!isset($_SESSION['user']['email'])) {
    header("Location: ../public/login.php");
    exit();
}


// Database connection
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "Nuxeria";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user coins for display
$email = $_SESSION['user']['email']; // Get email from session
$stmt = $conn->prepare("SELECT coins FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($coins); // Get the user's coin balance
$stmt->fetch();
$stmt->close();

$conn->close();

// Handle logout
if (isset($_POST['logout'])) {
    session_destroy(); // Destroy the session
    header("Location: ../public/login.php"); // Redirect to login page
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    
    <style>
        /* General styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #101010, #1A1A1A);
            height: 100vh;
            display: flex;
            flex-direction: column;
            font-family: 'Arial', sans-serif;
            color: white;
        }

        /* Main layout container for centering */
        .main-layout {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 60px); /* Full height minus header */
            margin-left: 220px; /* Default margin-left for sidebar */
            transition: margin-left 0.3s ease;
        }

        /* Header styles */
        header {
            display: flex;
            justify-content: space-between; /* Align items at the ends */
            align-items: center;
            background-color: #101010;
            padding: 10px 20px;
            position: relative;
        }

        /* Sidebar toggle button (inside header) */
        .menu-toggle {
            background-color: #000;
            color: white;
            border: none;
            font-size: 24px;
            padding: 10px;
            cursor: pointer;
            margin-right: 20px; /* Space between button and logo */
            transition: background 0.3s;
            border-radius: 5px; /* Rounded edges */
        }

        .menu-toggle:hover {
            background-color: #00FF88;
        }

        .logo img {
            height: 50px;
            margin-left: 10px;
        }

        nav ul {
            list-style-type: none;
            display: flex;
            margin-left: 20px;
        }

        nav ul li {
            margin: 0 15px;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        /* Persistent Sidebar styles */
        .sidebar {
            position: fixed;
            top: 72px; /* Below the header */
            left: -220px; /* Initially hidden */
            background-color: #000000;
            width: 200px;
            height: calc(98vh - 60px); /* Full height minus header */
            z-index: 10;
            overflow-y: auto;
            padding: 20px;
            border-top-right-radius: 15px; /* Top right corner rounding */
            border-bottom-right-radius: 15px; /* Bottom right corner rounding */
            box-shadow: 0 0 10px 5px rgba(0, 255, 136, 0.4); /* Green radiance shadow */
            transition: left 0.3s ease; /* Smooth transition */
        }

        /* Sidebar visible state */
        .sidebar.open {
            left: 0; /* Sidebar slides in */
        }

        /* Dropdown menu items styling */
        .dropdown-content {
            display: flex;
            flex-direction: column;
        }

        .dropdown-item {
            padding: 15px;
            color: white;
            text-decoration: none;
            transition: background 0.3s;
            margin-bottom: 15px; /* Add spacing between each item */
        }

        .dropdown-item:hover {
            background-color: #00FF88;
        }

        /* Centered Main content */
        .main-content {
            text-align: center;
        }

        /* Profile Dropdown Styles */
        .user-profile {
            position: relative; /* Position for absolute dropdown */
            display: flex; /* Align profile and notification horizontally */
            align-items: center; /* Center items vertically */
            margin-left: auto; /* Align to the right of the header */
        }

        .profile-picture {
            cursor: pointer; /* Cursor change on hover */
            display: flex;
            align-items: center; /* Align vertically */
        }

        .profile-picture img {
            width: 50px; /* Set desired width */
            height: 50px; /* Set desired height */
            border-radius: 50%; /* Circular profile picture */
            object-fit: cover; /* Maintain aspect ratio and cover the area */
            margin-left: 10px; /* Space between notification and profile */
        }

        .notification-button {
            cursor: pointer; /* Cursor change on hover */
            width: 50px; /* Set width for notification icon */
            height: 50px; /* Set height for notification icon */
            margin-right: 10px; /* Space between notification and profile */
        }

        .dropdown-menu {
            display: none; /* Hide by default */
            position: absolute; /* Position it absolutely */
            top: 60px; /* Position below the profile picture */
            right: 0; /* Align to the right */
            background-color: #333; /* Dropdown background color */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Shadow effect */
            z-index: 1000; /* Ensure it appears above other elements */
            padding: 10px; /* Padding inside the dropdown */
            min-width: 150px; /* Minimum width of dropdown */
            transition: display 0.3s ease; /* Smooth transition */
        }

        .profile-picture:hover + .dropdown-menu {
            display: block; /* Show on hover over profile picture */
        }

        .dropdown-menu a {
            display: block; /* Block display for links */
            color: white; /* Text color */
            padding: 10px 15px; /* Padding for links */
        }

        .dropdown-menu a:hover {
            background-color: #00FF88; /* Change background on hover */
        }

        .balance {
            color: #00FF88; /* Currency balance color */
            font-weight: bold; /* Bold font for emphasis */
            margin-bottom: 10px; /* Space below the balance */
        }

        /* Footer styles */
        footer {
            display: flex;
            justify-content: space-between;
            background-color: #101010;
            padding: 20px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        .footer-left, .footer-center, .footer-right {
            flex: 1;
            text-align: center;
        }

        .footer-left p, .footer-center p, .footer-right p {
            margin: 0 10px;
        }

        .footer-right a, .footer-center a {
            color: white;
            text-decoration: none;
        }

        /* Hover effect for footer links */
        .footer-right a:hover, .footer-center a:hover {
            text-decoration: underline;
        }
        .login-button {
    cursor: pointer;
    width: 60px; /* Set width for notification icon */
    height: 60px; /* Set height for notification icon */
    margin-right: 10px; /* Space between notification and profile */
    border: none; /* Remove any border */
    box-shadow: none; /* Remove any box-shadow */
    outline: none; /* Remove focus outline if any */
    background-color: transparent; /* Optional: Ensure no background color */
}

        .daily-login {
    display: flex; /* Align content horizontally */
    align-items: center; /* Center the icon vertically */
    margin-right: 10px; /* Space between this and the notification icon */
}
* {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .container {
            width: 80%;
            max-width: 1200px;
        }

        /* User's coin balance box */
        .user-info {
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 250px;
            margin-Left: 250px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
        }

        .user-info h2 {
            margin-bottom: 10px;
        }

        .coin-value {
            font-size: 1.5rem;
            color: #00FF88;
            font-weight: bold;
        }

        /* Product display area */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }

        .product {
            background-color: #222;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 255, 136, 0.3);
            transition: transform 0.3s ease;
        }

        .product:hover {
            transform: scale(1.05);
        }

        .product img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .product-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .product-price {
            font-size: 1.2rem;
            color: #00FF88;
        }

        .buy-btn {
            background-color: #00FF88;
            border: none;
            color: white;
            padding: 10px 20px;
            font-size: 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .buy-btn:hover {
            background-color: #00cc66;
        }

    </style>
</head>
<body>
    <header>
        <!-- Sidebar Toggle Button (inside header, before logo) -->
        <button class="menu-toggle">☰</button>

        <div class="logo">
            <img src="../assets/images/nuxeria-logo.png" alt="Nuxeria Logo">
        </div>
        <nav>
            <ul>
                <li><a href="dashboard2.html" class="nav-link">Dashboard</a></li>
                <li><a href="courses.html" class="nav-link">Courses</a></li>
                <li><a href="Tools.html" class="nav-link">Tools</a></li>
            </ul>
        </nav>
        <!-- Profile Section -->          
        <div class="user-profile">
    <img src="../assets/images/notifbell.png" alt="Notifications" id="notificationBtn" class="notification-button">
    <div class="profile-picture">
        <img src="../assets/images/default-profile.png" alt="Profile Picture" id="profileImg">
    </div>
    <div class="dropdown-menu">
        <div class="balance">Nuxecoin: $ <?php echo $coins; ?></div>
        <a href="profile.php">View Profile</a>
        <a href="settings.php">Settings</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

    </header>
    <div class="container">
        <!-- User Info Section -->
        <div class="user-info">
            <div class="">
            <div class="coin-value">Your Nuxecoin Balance: $ <?php echo $coins; ?></div>
        </div>

        <!-- Product Grid -->
        <div class="product-grid">
            <!-- Product 1 -->
            <div class="product">
                <img src="https://via.placeholder.com/250" alt="Product 1">
                <div class="product-name">50 Nuxecoins</div>
                <div class="product-price">P50</div>
                <button class="buy-btn">Buy Now</button>
            </div>

            <!-- Product 2 -->
            <div class="product">
                <img src="https://via.placeholder.com/250" alt="Product 2">
                <div class="product-name">100 Nuxecoins</div>
                <div class="product-price">P100</div>
                <button class="buy-btn">Buy Now</button>
            </div>

            <!-- Product 3 -->
            <div class="product">
                <img src="https://via.placeholder.com/250" alt="Product 3">
                <div class="product-name">500 Nuxecoins</div>
                <div class="product-price">P500</div>
                <button class="buy-btn">Buy Now</button>
            </div>

            <!-- Product 4 -->
            <div class="product">
                <img src="https://via.placeholder.com/250" alt="Product 4">
                <div class="product-name">1000 Nuxecoins</div>
                <div class="product-price">$1000</div>
                <button class="buy-btn">Buy Now</button>
            </div>

        </div>
    </div>
    <!-- Persistent Sidebar -->
    <div class="sidebar">
        <div class="dropdown-content">
            <a href="feed.html" class="dropdown-item">Feed</a>
            <a href="messages.html" class="dropdown-item">Messages</a>
            <a href="conferences.html" class="dropdown-item">Conferences</a>
            <a href="support.html" class="dropdown-item">Support</a>
        </div>
    </div>

    <script>
        // Sidebar toggle functionality
        const menuToggle = document.querySelector('.menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        const mainLayout = document.querySelector('.main-layout');

        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            mainLayout.style.marginLeft = sidebar.classList.contains('open') ? '220px' : '0'; 
        });

        // Notification redirect
        const notificationBtn = document.getElementById('notificationBtn');
        notificationBtn.addEventListener('click', () => {
            window.location.href = 'notification.html'; // Redirect to notifications page
        });
        const loginsBtn = document.getElementById('loginsBtn');
        loginsBtn.addEventListener('click', () => {
            window.location.href = 'daily.html'; // Redirect to notifications page
        });
         // Dropdown functionality with delay
         const profilePicture = document.querySelector('.profile-picture');
            const dropdownMenu = document.querySelector('.dropdown-menu');
            let timeoutId;

            profilePicture.addEventListener('mouseenter', function () {
                clearTimeout(timeoutId);
                dropdownMenu.style.display = 'block'; // Show dropdown on hover
            });

            profilePicture.addEventListener('mouseleave', function () {
                timeoutId = setTimeout(() => {
                    dropdownMenu.style.display = 'none'; // Hide dropdown after delay
                }, 300); // Delay of 300ms
            });

            dropdownMenu.addEventListener('mouseenter', function () {
                clearTimeout(timeoutId); // Clear timeout if hovering over dropdown
            });

            dropdownMenu.addEventListener('mouseleave', function () {
                timeoutId = setTimeout(() => {
                    dropdownMenu.style.display = 'none'; // Hide dropdown after delay
                }, 300); // Delay of 300ms
            });
    </script>
</body>
</html>
