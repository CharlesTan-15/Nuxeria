<?php
session_start();
include 'config.php';  // Include your database connection file

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    echo json_encode(['status' => 'error', 'message' => 'Please log in first.']);
    exit;
}

$user_id = $_SESSION['user'];

// Check if the user has already claimed the coins in the last 24 hours
$query = "SELECT claim_date FROM users WHERE user_id = '$user_id'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $last_claim = $row['claim_date'];

    // Check if the user has claimed within the last 24 hours
    if ($last_claim && (strtotime($last_claim) > time() - 86400)) {
        // If the claim date is within the last 24 hours, prompt an error
        echo json_encode(['status' => 'error', 'message' => 'You have already claimed your coins today. Please wait 24 hours before claiming again.']);
        exit;
    }
}

// If user can claim, award coins and update claim_date
$coins_awarded = 10;  // Example: 10 coins awarded per claim
$update_query = "UPDATE users SET coins = coins + $coins_awarded, claim_date = NOW() WHERE user_id = '$user_id'";

if (mysqli_query($conn, $update_query)) {
    echo json_encode(['status' => 'success', 'message' => 'Coins claimed successfully!', 'coins' => $coins_awarded]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to claim coins.']);
}

mysqli_close($conn);
?>
