<?php
// Database configuration
$host = "localhost";  // Database server
$username = "root";    // Database username
$password = "";        // Database password
$database = "nuxeria"; // Database name

// Create a connection to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set the character encoding
mysqli_set_charset($conn, "utf8");

// You can also define constants here
define('SITE_URL', 'http://localhost/nuxeria/');
?>
