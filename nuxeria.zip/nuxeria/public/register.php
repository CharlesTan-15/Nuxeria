<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "Nuxeria";

// Create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
    $registration_date = date("Y-m-d H:i:s"); // Get the current date and time

    // Check if the user already exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "User already exists.";
    } else {
        // Insert new user with backticks around `date`
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, `date`) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password, $registration_date);
        $stmt->execute();

        header("Location: login.html"); // Redirect to login page
        exit(); // Ensure no further code is executed after redirection
    }

    $stmt->close();
}

$conn->close();
?>
