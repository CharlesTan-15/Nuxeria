<?php
session_start();

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "Nuxeria";

// Create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $emailOrName = $_POST['email_or_name'];  // Email or Name
    $password = $_POST['password'];

    // Update the query to select email, name, password, role, claim_date, and coins
    $stmt = $conn->prepare("SELECT id, name, email, password, role, claim_date, coins FROM users WHERE email = ? OR name = ?");
    $stmt->bind_param("ss", $emailOrName, $emailOrName);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $name, $email, $hashedPassword, $role, $claimDate, $coins);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashedPassword)) {
            // Store user data in an associative array, including role
            $_SESSION['user'] = [
                'id' => $id,
                'name' => $name,
                'email' => $email,
                'role' => $role, // Add role to session data
                'coins' => $coins // Add current coin balance to session
            ];

            // Check if 24 hours have passed since the user last claimed coins
            $currentTime = new DateTime();
            $lastClaimTime = new DateTime($claimDate);
            $interval = $currentTime->diff($lastClaimTime);

            if ($interval->h >= 24 || $claimDate === null) {
                // Award coins to the user (e.g., 50 coins)
                $newCoins = $coins + 50;

                // Update the user's coin balance and claim_date
                $updateStmt = $conn->prepare("UPDATE users SET coins = ?, claim_date = NOW() WHERE id = ?");
                $updateStmt->bind_param("ii", $newCoins, $id);
                $updateStmt->execute();

                // Update the session with the new coin balance
                $_SESSION['user']['coins'] = $newCoins;
                // After the login process is successful
                $_SESSION['success_message'] = "50 Nuxecoins have been automatically added to your account for logging in today.";

               // Redirect to the dashboard or home page
               header("Location: dashboard.php");
            exit();

            }

            // Redirect based on user role
            if ($role === 'admin') {
                header("Location: ../admin/dashboard.html"); // Redirect to admin dashboard
            } else {
                header("Location: ../user/dashboard2.html"); // Redirect to user dashboard
            }
            exit(); // Always exit after a redirect
        } else {
            $_SESSION['error'] = "Invalid password.";
        }
    } else {
        $_SESSION['error'] = "No user found with that email or name.";
    }
    $stmt->close();
}

// Display error message if it exists
if (isset($_SESSION['error'])) {
    $error_message = $_SESSION['error'];
    unset($_SESSION['error']); // Clear the error message after displaying it
} else {
    $error_message = ""; // No error message
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In - Nuxeria</title>
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="../assets/images/nuxeria-logo.png" alt="Nuxeria Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.html" class="nav-link">Home</a></li>
                <li><a href="about.html" class="nav-link">About</a></li>
            </ul>
        </nav>
        <div class="login">
            <a href="login.php" class="login-button">Log In</a>
        </div>
    </header>

    <main class="login-container">
        <h2>Log In to Your Account</h2>
        <form id="login-form" action="login.php" method="POST">
    <div class="form-group">
        <label for="email_or_name">Email or Name:</label>
        <input type="text" id="email_or_name" name="email_or_name" required placeholder="you@example.com or Name">
    </div>
    <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required placeholder="Enter your password">
    </div>
    <button type="submit" class="cta-button">Log In</button>
    <p class="alternative-action">Don't have an account? <a href="register.html">Register here</a></p>
</form>

        <?php if ($error_message): ?>
            <p class="error-message" style="color:red;"><?= htmlspecialchars($error_message) ?></p>
        <?php endif; ?>
    </main>
</body>
</html>
