<?php
session_start();

// Check if the user is logged in and has admin privileges
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../public/login.php"); // Redirect to login if not logged in or not an admin
    exit();
}

// Database connection
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "Nuxeria";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle password update for another user
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $target_email = $_POST['email']; // The email of the user whose password will be updated
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Fetch the user data from the database
    $stmt = $conn->prepare("SELECT name, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $target_email);
    $stmt->execute();
    $stmt->store_result();  // Store the result to check if the user exists

    if ($stmt->num_rows > 0) {
        // User found, now fetch the data
        $stmt->bind_result($name, $hashed_password); // Get both name and hashed password
        $stmt->fetch();

        // Verify current password
        if (password_verify($current_password, $hashed_password)) {
            // Check if new passwords match
            if ($new_password === $confirm_password) {
                // Hash the new password and update it in the database
                $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
                $stmt->bind_param("ss", $new_hashed_password, $target_email);
                $stmt->execute();
                echo "<script>alert('Password for user {$target_email} updated successfully.');</script>";
            } else {
                echo "<script>alert('New passwords do not match.');</script>";
            }
        } else {
            echo "<script>alert('Current password is incorrect.');</script>";
        }
    } else {
        echo "<script>alert('User not found.');</script>";
    }

    $stmt->close();
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change User Password - Nuxeria</title>
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <style>
        .settings-box {
            border: 1px solid #ccc;
            border-radius: 15px;
            padding: 20px;
            margin: 20px auto;
            background-color: #5A5A5A;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 90%;
        }
        h2, h3 {
            text-align: center;
        }
        input[type="password"], input[type="email"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-bottom: 15px;
        }
        .update-button {
            padding: 10px 15px;
            border: none;
            border-radius: 25px;
            background-color: #8A9A5B;
            color: white;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
        }
        .update-button:hover {
            background-color: #006400;
        }
        /* General styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #101010, #1A1A1A);
            height: 100vh;
            display: flex;
            flex-direction: column;
            font-family: 'Arial', sans-serif;
            color: white;
        }

        /* Main layout container for centering */
        .main-layout {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 60px);
            margin-left: 220px;
            transition: margin-left 0.3s ease;
        }

        /* Header styles */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #101010;
            padding: 10px 20px;
            position: relative;
        }

        /* Sidebar toggle button (inside header) */
        .menu-toggle {
            background-color: #000;
            color: white;
            border: none;
            font-size: 24px;
            padding: 10px;
            cursor: pointer;
            margin-right: 20px;
            transition: background 0.3s;
            border-radius: 5px;
        }

        .menu-toggle:hover {
            background-color: #00FF88;
        }

        .logo img {
            height: 50px;
            margin-left: 10px;
        }

        nav ul {
            list-style-type: none;
            display: flex;
            margin-left: 20px;
        }

        nav ul li {
            margin: 0 15px;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .sidebar {
            position: fixed;
            top: 72px;
            left: -220px;
            background-color: #000000;
            width: 200px;
            height: calc(98vh - 60px);
            z-index: 10;
            overflow-y: auto;
            padding: 20px;
            border-top-right-radius: 15px;
            border-bottom-right-radius: 15px;
            box-shadow: 0 0 10px 5px rgba(0, 255, 136, 0.4);
            transition: left 0.3s ease;
        }

        .sidebar.open {
            left: 0;
        }

        .dropdown-content {
            display: flex;
            flex-direction: column;
        }

        .dropdown-item {
            padding: 15px;
            color: white;
            text-decoration: none;
            transition: background 0.3s;
            margin-bottom: 15px;
        }

        .dropdown-item:hover {
            background-color: #00FF88;
        }

        .main-content {
            text-align: center;
        }

        .user-profile {
            position: relative;
            display: flex;
            align-items: center;
            margin-left: auto;
        }

        .profile-picture {
            cursor: pointer;
            display: flex;
            align-items: center;
        }

        .profile-picture img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-left: 10px;
        }

        .notification-button {
            cursor: pointer;
            width: 50px;
            height: 50px;
            margin-right: 10px;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 60px;
            right: 0;
            background-color: #333;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            z-index: 1000;
            padding: 10px;
            min-width: 150px;
            transition: display 0.3s ease;
        }

        .profile-picture:hover + .dropdown-menu {
            display: block;
        }

        .dropdown-menu a {
            display: block;
            color: white;
            padding: 10px 15px;
        }

        .dropdown-menu a:hover {
            background-color: #00FF88;
        }

        .balance {
            color: #00FF88;
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <header>
        <button class="menu-toggle">☰</button>
        <div class="logo">
            <img src="../assets/images/nuxeria-logo.png" alt="Nuxeria Logo">
        </div>
        <nav>
            <ul>
                <li><a href="dashboard2.html" class="nav-link">Dashboard</a></li>
                <li><a href="courses.html" class="nav-link">Courses</a></li>
                <li><a href="Tools.html" class="nav-link">Tools</a></li>
            </ul>
        </nav>
        <div class="user-profile">
            <img src="../assets/images/notifbell.png" alt="Notifications" id="notificationBtn" class="notification-button">
            <div class="profile-picture">
                <img src="../assets/images/default-profile.png" alt="Profile Picture" id="profileImg">
            </div>
            <div class="dropdown-menu">
                <a href="profile.php">Profile</a>
                <a href="settings.php">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="sidebar">
        <div class="dropdown-content">
            <a href="dashboard.html" class="dropdown-item">Feed</a>
            <a href="messages.html" class="dropdown-item">Messages</a>
            <a href="conferences.html" class="dropdown-item">Conferences</a>
            <a href="support.html" class="dropdown-item">Support</a>
        </div>
    </div>

    <div class="main-layout">
        <div class="settings-box">
            <h2>Update User Password</h2>
            <form method="POST">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required placeholder="Enter user's email">
                <label for="current_password">Current Password:</label>
                <input type="password" id="current_password" name="current_password" required placeholder="Enter current password">
                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" required placeholder="Enter new password">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required placeholder="Confirm new password">
                <button type="submit" name="update_password" class="update-button">Update Password</button>
            </form>
        </div>
    </div>

    <script>
        const profilePicture = document.querySelector('.profile-picture');
        const dropdownMenu = document.querySelector('.dropdown-menu');

        profilePicture.addEventListener('mouseenter', function () {
            dropdownMenu.style.display = 'block';
        });

        profilePicture.addEventListener('mouseleave', function () {
            dropdownMenu.style.display = 'none';
        });

        dropdownMenu.addEventListener('mouseenter', function () {
            dropdownMenu.style.display = 'block';
        });

        dropdownMenu.addEventListener('mouseleave', function () {
            dropdownMenu.style.display = 'none';
        });

        const menuToggle = document.querySelector('.menu-toggle');
        const sidebar = document.querySelector('.sidebar');
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            localStorage.setItem('sidebarOpen', sidebar.classList.contains('open') ? 'true' : 'false');
        });

        if (localStorage.getItem('sidebarOpen') === 'true') {
            sidebar.classList.add('open');
        }
    </script>
</body>
</html>
