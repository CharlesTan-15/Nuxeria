<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: ../public/login.php"); // Redirect to login if not logged in
    exit();
}

// Database connection
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "Nuxeria";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['user']['email']; // Get email from session
$stmt = $conn->prepare("SELECT name, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($name, $hashed_password); // Get both name and hashed password
$stmt->fetch();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuxeria</title>
    
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <style>
    /* General styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, #101010, #1A1A1A);
    height: 100vh;
    display: flex;
    flex-direction: column;
    font-family: 'Arial', sans-serif;
    color: white;
}

/* Main layout container for centering */
.main-layout {
    display: flex;
    justify-content: center;
    align-items: center;
    height: calc(100vh - 60px); /* Full height minus header */
    margin-left: 220px; /* Default margin-left for sidebar */
    transition: margin-left 0.3s ease;
}

/* Header styles */
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #101010;
    padding: 10px 20px;
    position: relative;
}

/* Sidebar toggle button (inside header) */
.menu-toggle {
    background-color: #000;
    color: white;
    border: none;
    font-size: 24px;
    padding: 10px;
    cursor: pointer;
    margin-right: 20px; /* Space between button and logo */
    transition: background 0.3s;
    border-radius: 5px; /* Rounded edges */
}

.menu-toggle:hover {
    background-color: #00FF88;
}

.logo img {
    height: 50px;
    margin-left: 10px;
}

nav ul {
    list-style-type: none;
    display: flex;
    margin-left: 20px;
}

nav ul li {
    margin: 0 15px;
}

.nav-link {
    color: white;
    text-decoration: none;
    font-weight: bold;
}

/* Persistent Sidebar styles */
.sidebar {
    position: fixed;
    top: 72px; /* Below the header */
    left: -220px; /* Initially hidden */
    background-color: #000000;
    width: 220px;
    height: calc(98vh - 60px); /* Full height minus header */
    z-index: 10;
    overflow-y: auto;
    padding: 20px;
    box-shadow: 0 0 10px 5px rgba(0, 255, 136, 0.4); /* Green radiance shadow */
    transition: left 0.3s ease; /* Smooth transition */
    border-radius: 10px; /* Adding rounded corners to sidebar */
}

/* Sidebar visible state */
.sidebar.open {
    left: 0; /* Sidebar slides in */
}

/* Sidebar Links Styling */
.sidebar ul {
    list-style-type: none; /* Remove default bullet points */
    padding: 0;
    margin: 0;
}

.sidebar ul li {
    margin: 15px 0; /* Space between items */
}

.sidebar ul li a {
    display: block; /* Make links block elements for easy styling */
    padding: 10px 0; /* Space around the link text */
    color: white; /* Text color */
    text-decoration: none; /* Remove underline from links */
    font-size: 16px; /* Adjust font size */
    transition: color 0.3s ease; /* Smooth transition on hover */
}

.sidebar ul li a:hover {
    color: #00FF88; /* Change text color to green on hover */
}

/* Profile Dropdown Styles */
.user-profile {
    position: relative;
    display: flex;
    align-items: center;
    margin-left: auto;
}

.profile-picture {
    cursor: pointer;
}

.profile-picture img {
    width: 50px;
    height: 50px;
    border-radius: 50%; /* Keeps profile picture round */
    object-fit: cover;
    transition: transform 0.2s;
}

.notification-button {
    cursor: pointer;
    width: 50px;
    height: 50px;
    margin-right: 10px;
}

.dropdown-menu {
    display: none;
    position: absolute;
    top: 60px;
    right: 0;
    background-color: #333;
    border-radius: 10px; /* Rounded corners for the dropdown menu */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    z-index: 1000;
    padding: 10px;
    min-width: 150px;
}

.profile-picture:hover + .dropdown-menu {
    display: block;
}

.dropdown-menu a {
    display: block;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
}

.dropdown-menu a:hover {
    background-color: #00FF88;
}

.balance {
    color: #00FF88;
    font-weight: bold;
    margin-bottom: 10px;
}

/* Profile Box Styling */
.profile-box {
    background-color: #333; /* Dark background for the box */
    border-radius: 10px; /* Rounded corners */
    padding: 20px;
    margin-top: 20px;
    box-shadow: 0 0 10px rgba(0, 255, 136, 0.4); /* Green shadow effect */
}

.profile-box h3 {
    color: #00FF88; /* Green color for the heading */
    margin-bottom: 15px; /* Space between title and content */
}

.profile-box p {
    color: white;
    margin: 5px 0; /* Space between each line */
}

.profile-box p strong {
    color: #00FF88; /* Green color for labels like Name, Email */
}

/* Profile Picture Styling */
.profile-picture img {
    border-radius: 50%; /* Circular profile picture */
    width: 50px; /* Reverting the size back to 50px */
    height: 50px; /* Ensuring it stays 50px */
    object-fit: cover;
}

/* Footer styles */
footer {
    display: flex;
    justify-content: space-between;
    background-color: #101010;
    padding: 20px 0;
    position: relative;
    bottom: 0;
    width: 100%;
}

.footer-left, .footer-center, .footer-right {
    flex: 1;
    text-align: center;
}

.footer-left p, .footer-center p, .footer-right p {
    margin: 0 10px;
}

.footer-right a, .footer-center a {
    color: white;
    text-decoration: none;
}

/* Hover effect for footer links */
.footer-right a:hover, .footer-center a:hover {
    text-decoration: underline;
}

    
</style>

    


        
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
    <ul>
        <li><a href="feed.html">Feed</a></li>
        <li><a href="messages.html">Messages</a></li>
        <li><a href="conferences.html">Conferences</a></li>
        <li><a href="support.html">Support</a></li>
    </ul>
</div>

    <!-- Header -->
    <header>
        <button class="menu-toggle">☰</button> <!-- Sidebar toggle button -->
        <div class="logo">
            <img src="../assets/images/nuxeria-logo.png" alt="Nuxeria Logo">
        </div>
        <nav>
            <ul>
                <li><a href="dashboard2.html" class="nav-link">Dashboard</a></li>
                <li><a href="courses.html" class="nav-link">Courses</a></li>
                <li><a href="Tools.html" class="nav-link">Tools</a></li>
            </ul>
        </nav>
        <div class="user-profile">
            <img src="../assets/images/notifbell.png" alt="Notifications" id="notificationBtn" class="notification-button">
            <div class="profile-picture">
                <img src="../assets/images/default-profile.png" alt="Profile Picture" id="profileImg">
            </div>
            <div class="dropdown-menu">
                <div class="balance">Balance: $100.00</div>
                <a href="profile.php">View Profile</a>
                <a href="settings.php">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="main-layout">
    <div class="form-container">
        <h2>Your Profile</h2>
        <!-- Rounded Box for Profile Content -->
        <div class="profile-box">
            <div class="user-info">
                <div class="profile-picture">
                    <img src="../assets/images/default-profile.png" alt="Profile Picture" id="profileImg">
                </div>
                <div>            
                    <p><strong>Name:</strong> <?= htmlspecialchars($name) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($email) ?></p>
                </div>
            </div>
        </div>
    </div>
</div>


    <script>
       document.addEventListener("DOMContentLoaded", function () {
    const notificationBtn = document.getElementById("notificationBtn");
    notificationBtn.addEventListener("click", function () {
        window.location.href = "notification.html"; // Redirect to notifications page
    });

    const sidebar = document.querySelector('.sidebar');
    const mainLayout = document.querySelector('.main-layout');
    const toggleButton = document.querySelector('.menu-toggle');

    // Check local storage for sidebar state
    if (localStorage.getItem('sidebarOpen') === 'true') {
        sidebar.classList.add('open');
        mainLayout.classList.add('with-sidebar'); // Adjust layout
    }

    // Toggle sidebar open/close on button click
    toggleButton.addEventListener('click', function () {
        sidebar.classList.toggle('open');
        const isOpen = sidebar.classList.contains('open');
        mainLayout.classList.toggle('with-sidebar', isOpen); // Adjust layout
        localStorage.setItem('sidebarOpen', isOpen); // Save sidebar state in localStorage
    });

    // Dropdown functionality with delay
    const profilePicture = document.querySelector('.profile-picture');
    const dropdownMenu = document.querySelector('.dropdown-menu');
    let timeoutId;

    profilePicture.addEventListener('mouseenter', function () {
        clearTimeout(timeoutId);
        dropdownMenu.style.display = 'block'; // Show dropdown on hover
    });

    profilePicture.addEventListener('mouseleave', function () {
        timeoutId = setTimeout(() => {
            dropdownMenu.style.display = 'none'; // Hide dropdown after delay
        }, 300); // Delay of 300ms
    });

    dropdownMenu.addEventListener('mouseenter', function () {
        clearTimeout(timeoutId); // Clear timeout if hovering over dropdown
    });

    dropdownMenu.addEventListener('mouseleave', function () {
        timeoutId = setTimeout(() => {
            dropdownMenu.style.display = 'none'; // Hide dropdown after delay
        }, 300); // Delay of 300ms
    });
}); // Corrected closing brace



    </script>
</body>
</html>
