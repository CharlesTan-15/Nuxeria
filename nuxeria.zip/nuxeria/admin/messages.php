<?php
$servername = "localhost"; // Your database server
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "Nuxeria"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch messages
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $receiver_id = 1; // Replace with actual receiver ID
    $sql = "SELECT * FROM messages WHERE receiver_id = $receiver_id ORDER BY timestamp ASC";
    $result = $conn->query($sql);
    $messages = [];
    
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    
    echo json_encode($messages);
}

// Send message
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sender_id = 1; // Replace with actual sender ID
    $receiver_id = 1; // Replace with actual receiver ID
    $message_text = $_POST['message_text'];

    $sql = "INSERT INTO messages (sender_id, receiver_id, message_text) VALUES ($sender_id, $receiver_id, '$message_text')";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }
}

$conn->close();
?>
